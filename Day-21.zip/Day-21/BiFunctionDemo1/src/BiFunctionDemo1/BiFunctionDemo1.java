package BiFunctionDemo1;

import java.util.ArrayList;
import java.util.function.BiPredicate;

class shoes{
	int shoesId;
	String shoesName;
	int shoesCost;
	int shockesCost;
	int laseCost;
	public shoes(int shoesId, String shoesName, int shoesCost, int shockesCost, int laseCost) {
		super();
		this.shoesId = shoesId;
		this.shoesName = shoesName;
		this.shoesCost = shoesCost;
		this.shockesCost = shockesCost;
		this.laseCost = laseCost;
	}
}

public class BiFunctionDemo1 {

	public static void main(String[] args) {
		
		ArrayList <shoes> shoesList = new ArrayList<shoes>();
		shoesList.add(new shoes(101, "Nike", 42, 32,40));
		shoesList.add(new shoes(102, "Addidas", 12, 8,12));
		shoesList.add(new shoes(103, "PUMA", 24, 10,48));
		shoesList.add(new shoes(104, "Bata", 21, 16,5));
		
		BiPredicate<Integer, Integer> obj1 = (shoe, shockes) -> ((shoe + shockes) >= 50); 
		BiPredicate<Integer, Integer> obj2 = (lase, shockes) -> ((lase + shockes) < 50); 
		
		for(shoes cost1 : shoesList) {
			if(obj1.test(cost1.shoesCost, cost1.shockesCost)) {
				System.out.println("High cost");
			}
			else {
				System.out.println("low cost");
			}
		}
		
		for (shoes cost2 : shoesList) {
			if(obj2.test(cost2.laseCost,cost2.shockesCost)) {
				System.out.println("Normal cost");
			}
			else {
				System.out.println("High cost");
			}
		}
		
	}

}
