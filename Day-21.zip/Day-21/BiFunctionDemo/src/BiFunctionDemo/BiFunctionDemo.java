package BiFunctionDemo;

import java.util.function.BiPredicate;

public class BiFunctionDemo {

	public static void main(String[] args) {
		BiPredicate<Integer, Integer> obj1 =  (a,b) ->((a+b) % 2 == 0);
		System.out.println("The result is : " +obj1.test(4,5));
		System.out.println("The result is : " +obj1.test(5,5));
	
	}

}
