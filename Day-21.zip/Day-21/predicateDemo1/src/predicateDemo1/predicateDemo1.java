package predicateDemo1;

import java.util.ArrayList;
import java.util.function.Predicate;

class student {
	
	int studentId, studentAge;
	String studentName;
	public student(int studentId, String studentName, int studentAge) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAge = studentAge;
	}	
}
public class predicateDemo1 {

	public static void main(String[] args) {
		
		ArrayList <student> StudentDrtails = new ArrayList();
		
		StudentDrtails.add(new student(1321,"Tom",34 ));
		StudentDrtails.add(new student(1334,"Jack",21 ));
		StudentDrtails.add(new student(1389,"John",12 ));
		StudentDrtails.add(new student(1310,"Peter",11 ));
		StudentDrtails.add(new student(1362,"Stark",25 ));
		
		Predicate <student> pre = (age) -> {
			if(age.studentAge > 18) {
				
				return true;				
			}
			else {
				return false;
			}
			
		};
		
		for(student age : StudentDrtails ) {			
			if(pre.test(age)) {
				System.out.println( "Allow watching movies ");
				System.out.println("Student name - :" + age.studentName);				
			}
			else if (!(pre.test(age))){
				System.out.println("Not allow movies");
				System.out.println("Student name - :" + age.studentName);
			}
		}
	}
}
